package dev.pvpcorevip;

import org.bukkit.*;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ArmorMeta;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.trim.ArmorTrim;
import org.bukkit.inventory.meta.trim.TrimMaterial;
import org.bukkit.inventory.meta.trim.TrimPattern;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Netherite zirh, trim, VIP lobi esyasi ve oldurme/vurus efektleri. */
public final class Cosmetics {
    public static final List<String> PATTERNS = List.of("sentry", "dune", "coast", "wild", "ward", "eye", "vex", "tide",
            "snout", "rib", "spire", "wayfinder", "shaper", "silence", "raiser", "host", "flow", "bolt");
    public static final List<String> TRIM_MATS = List.of("quartz", "iron", "netherite", "redstone", "copper", "gold",
            "emerald", "diamond", "lapis", "amethyst", "resin");
    public static final List<String> KILL_FX = List.of("NONE", "LIGHTNING", "FIREWORK", "HEARTS", "SOUL", "FLAME");

    public static final byte KIND_ARMOR = 1, KIND_ITEM = 2;

    private final VipPlugin plugin;
    private final NamespacedKey key;

    public Cosmetics(VipPlugin plugin) {
        this.plugin = plugin;
        this.key = new NamespacedKey(plugin, "vip_item");
    }

    // ---------- isaretleme ----------
    public byte kind(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return 0;
        Byte b = it.getItemMeta().getPersistentDataContainer().get(key, PersistentDataType.BYTE);
        return b == null ? 0 : b;
    }

    public void removeMarked(Player p, byte onlyKind) {
        PlayerInventory inv = p.getInventory();
        ItemStack[] c = inv.getContents();
        boolean changed = false;
        for (int i = 0; i < c.length; i++) {
            byte k = kind(c[i]);
            if (k != 0 && (onlyKind == 0 || k == onlyKind)) { c[i] = null; changed = true; }
        }
        if (changed) inv.setContents(c);
    }

    // ---------- zirh + trim ----------
    public ArmorTrim trimOf(UUID id) {
        String pat = plugin.data().getString(id, "trim.pattern", null);
        String mat = plugin.data().getString(id, "trim.material", null);
        if (pat == null || mat == null) return null;
        TrimPattern tp = Registry.TRIM_PATTERN.get(NamespacedKey.minecraft(pat));
        TrimMaterial tm = Registry.TRIM_MATERIAL.get(NamespacedKey.minecraft(mat));
        if (tp == null || tm == null) return null;
        return new ArmorTrim(tm, tp);
    }

    public ItemStack piece(UUID id, Material mat, String name) {
        ItemStack it = new ItemStack(mat);
        ArmorMeta meta = (ArmorMeta) it.getItemMeta();
        meta.setDisplayName(Text.c(name));
        meta.setUnbreakable(true);
        ArmorTrim trim = trimOf(id);
        if (trim != null) meta.setTrim(trim);
        meta.addItemFlags(ItemFlag.values());
        meta.getPersistentDataContainer().set(key, PersistentDataType.BYTE, KIND_ARMOR);
        it.setItemMeta(meta);
        return it;
    }

    public void applyArmor(Player p, boolean force) {
        UUID id = p.getUniqueId();
        PlayerInventory inv = p.getInventory();
        if (force) removeMarked(p, KIND_ARMOR);
        if (isEmpty(inv.getHelmet())) inv.setHelmet(piece(id, Material.NETHERITE_HELMET, "&5VIP Netherite Miğfer"));
        if (isEmpty(inv.getChestplate())) inv.setChestplate(piece(id, Material.NETHERITE_CHESTPLATE, "&5VIP Netherite Zırh"));
        if (isEmpty(inv.getLeggings())) inv.setLeggings(piece(id, Material.NETHERITE_LEGGINGS, "&5VIP Netherite Pantolon"));
        if (isEmpty(inv.getBoots())) inv.setBoots(piece(id, Material.NETHERITE_BOOTS, "&5VIP Netherite Bot"));
    }

    private boolean isEmpty(ItemStack i) { return i == null || i.getType() == Material.AIR; }

    // ---------- lobi esyasi ----------
    public ItemStack menuItem() {
        FileConfiguration c = plugin.getConfig();
        Material m = Material.matchMaterial(c.getString("vip-item.material", "NETHER_STAR"));
        ItemStack it = new ItemStack(m == null ? Material.NETHER_STAR : m);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(Text.c(c.getString("vip-item.name", "&dVIP")));
        List<String> lore = new ArrayList<>();
        for (String l : c.getStringList("vip-item.lore")) lore.add(Text.c(l));
        meta.setLore(lore);
        meta.getPersistentDataContainer().set(key, PersistentDataType.BYTE, KIND_ITEM);
        it.setItemMeta(meta);
        return it;
    }

    /** Lobi dunyasinda her oyuncu icin periyodik bakim. */
    public void tick(Player p) {
        if (!p.getWorld().getName().equalsIgnoreCase(plugin.getConfig().getString("lobby-world", "spawn"))) return;
        if (!plugin.isVip(p)) { removeMarked(p, (byte) 0); return; }
        if (plugin.data().getBool(p.getUniqueId(), "armor", false)) applyArmor(p, false);
        if (plugin.getConfig().getBoolean("vip-item.enabled", true)) {
            int slot = plugin.getConfig().getInt("vip-item.slot", 2);
            if (p.getInventory().getItem(slot) == null) p.getInventory().setItem(slot, menuItem());
        }
    }

    // ---------- efektler ----------
    public static void firework(Location l) {
        Firework fw = l.getWorld().spawn(l, Firework.class);
        FireworkMeta fm = fw.getFireworkMeta();
        fm.addEffect(FireworkEffect.builder().with(FireworkEffect.Type.BALL_LARGE)
                .withColor(Color.FUCHSIA, Color.AQUA).withFade(Color.WHITE).flicker(true).build());
        fw.setFireworkMeta(fm);
        fw.detonate();
    }

    public void killEffect(String id, Location l) {
        World w = l.getWorld();
        Location c = l.clone().add(0, 1, 0);
        switch (id) {
            case "LIGHTNING" -> w.strikeLightningEffect(l);
            case "FIREWORK" -> firework(l);
            case "HEARTS" -> w.spawnParticle(Particle.HEART, c, 25, 0.5, 0.6, 0.5, 0.01);
            case "SOUL" -> w.spawnParticle(Particle.SOUL, c, 30, 0.4, 0.7, 0.4, 0.02);
            case "FLAME" -> {
                w.spawnParticle(Particle.FLAME, c, 40, 0.4, 0.7, 0.4, 0.05);
                w.playSound(l, Sound.ITEM_FIRECHARGE_USE, 1f, 1f);
            }
            default -> {}
        }
    }

    public void hitParticle(String name, Location l) {
        try {
            Particle part = Particle.valueOf(name);
            l.getWorld().spawnParticle(part, l.clone().add(0, 1, 0), 12, 0.3, 0.5, 0.3, 0.05);
        } catch (IllegalArgumentException ignored) {}
    }

}

package dev.pvpcorevip;

import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.GameMode;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

import java.util.UUID;

public final class VipListener implements Listener {
    private final VipPlugin plugin;

    public VipListener(VipPlugin plugin) { this.plugin = plugin; }

    private Cosmetics cos() { return plugin.cosmetics(); }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        UUID id = p.getUniqueId();

        // sinematik sirasinda cokme olduysa oyun modunu geri ver
        if (plugin.data().has(id, "cinematic")) {
            String gm = plugin.data().getString(id, "cinematic.gm", "ADVENTURE");
            try { p.setGameMode(GameMode.valueOf(gm)); } catch (IllegalArgumentException ex) { p.setGameMode(GameMode.ADVENTURE); }
            p.setInvulnerable(false);
            plugin.data().set(id, "cinematic", null);
        }

        if (plugin.isVip(p) && plugin.getConfig().getBoolean("join-message.enabled", true)) {
            String msg = Text.fmt(plugin.getConfig().getString("join-message.text", ""), "%player%", p.getName());
            e.joinMessage(LegacyComponentSerializer.legacySection().deserialize(Text.c(msg)));
        }
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (p.isOnline()) { plugin.checkPending(p); cos().tick(p); }
        }, 40L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        plugin.cinematic().stop(e.getPlayer());
    }

    @EventHandler
    public void onSneak(PlayerToggleSneakEvent e) {
        if (e.isSneaking() && plugin.cinematic().isRunning(e.getPlayer())) plugin.cinematic().skip(e.getPlayer());
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        if (plugin.cinematic().isRunning(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onWorld(PlayerChangedWorldEvent e) {
        Player p = e.getPlayer();
        String lobby = plugin.getConfig().getString("lobby-world", "spawn");
        if (e.getFrom().getName().equalsIgnoreCase(lobby)) cos().removeMarked(p, Cosmetics.KIND_ARMOR);
        Bukkit.getScheduler().runTaskLater(plugin, () -> { if (p.isOnline()) plugin.checkPending(p); }, 20L);
    }

    // ---- VIP esyalarinin korunmasi ----
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onClick(InventoryClickEvent e) {
        ItemStack cur = e.getCurrentItem(), cursor = e.getCursor();
        boolean hot = false;
        if (e.getClick().name().equals("NUMBER_KEY") && e.getWhoClicked() instanceof Player p) {
            ItemStack h = p.getInventory().getItem(e.getHotbarButton());
            hot = cos().kind(h) != 0;
        }
        if (cos().kind(cur) != 0 || cos().kind(cursor) != 0 || hot) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent e) {
        if (cos().kind(e.getItemDrop().getItemStack()) != 0) e.setCancelled(true);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        e.getDrops().removeIf(i -> cos().kind(i) != 0);
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (cos().kind(e.getItem()) != Cosmetics.KIND_ITEM) return;
        e.setUseInteractedBlock(Event.Result.DENY);
        e.setUseItemInHand(Event.Result.DENY);
        Player p = e.getPlayer();
        if (plugin.isVip(p)) plugin.menus().openMain(p);
        else plugin.send(p, "locked");
    }

    // ---- efektler ----
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player a) || !(e.getEntity() instanceof Player v)) return;
        if (!plugin.isVip(a)) return;
        UUID id = a.getUniqueId();
        boolean kill = v.getHealth() - e.getFinalDamage() <= 0;
        if (kill) {
            String fx = plugin.data().getString(id, "fx.kill", "NONE");
            if (!fx.equals("NONE")) cos().killEffect(fx, v.getLocation());
        } else {
            String hp = plugin.data().getString(id, "fx.hit", "NONE");
            if (!hp.equals("NONE")) cos().hitParticle(hp, v.getLocation());
        }
    }
}

package dev.pvpcorevip;

import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;

public final class VipData {
    private final VipPlugin plugin;
    private final File file;
    private final YamlConfiguration yml;
    private boolean dirty;

    public VipData(VipPlugin plugin) {
        this.plugin = plugin;
        plugin.getDataFolder().mkdirs();
        this.file = new File(plugin.getDataFolder(), "data.yml");
        this.yml = YamlConfiguration.loadConfiguration(file);
    }

    private String k(UUID id, String key) { return "players." + id + "." + key; }

    public boolean getBool(UUID id, String key, boolean def) { return yml.getBoolean(k(id, key), def); }
    public String getString(UUID id, String key, String def) { return yml.getString(k(id, key), def); }
    public long getLong(UUID id, String key, long def) { return yml.getLong(k(id, key), def); }
    public boolean has(UUID id, String key) { return yml.contains(k(id, key)); }

    public void set(UUID id, String key, Object value) {
        yml.set(k(id, key), value);
        dirty = true;
    }

    public Set<UUID> openHosts() {
        Set<UUID> s = new LinkedHashSet<>();
        for (String x : yml.getStringList("open-parties")) {
            try { s.add(UUID.fromString(x)); } catch (IllegalArgumentException ignored) {}
        }
        return s;
    }

    public boolean isOpen(UUID id) { return openHosts().contains(id); }

    public void setOpen(UUID id, boolean open) {
        Set<UUID> s = openHosts();
        if (open) s.add(id); else s.remove(id);
        yml.set("open-parties", s.stream().map(UUID::toString).toList());
        dirty = true;
    }

    public void save() {
        if (!dirty) return;
        try {
            yml.save(file);
            dirty = false;
        } catch (IOException e) {
            plugin.getLogger().warning("data.yml kaydedilemedi: " + e.getMessage());
        }
    }
}

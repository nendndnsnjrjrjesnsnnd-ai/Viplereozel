package dev.pvpcorevip;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.io.File;
import java.io.IOException;
import java.util.*;

/** VIP alinca oynayan sinematik kamera: tesekkur basligi + lobide kamera turu + havai fisek. */
public final class Cinematic {
    private final VipPlugin plugin;
    private File file;
    private YamlConfiguration cfg;
    private final Map<UUID, Run> running = new HashMap<>();

    record Wp(Location loc, int ticks, String title, String sub) {}

    public Cinematic(VipPlugin plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        file = new File(plugin.getDataFolder(), "cinematic.yml");
        if (!file.exists()) plugin.saveResource("cinematic.yml", false);
        cfg = YamlConfiguration.loadConfiguration(file);
    }

    public boolean enabled() { return cfg.getBoolean("enabled", true); }
    public boolean isRunning(Player p) { return running.containsKey(p.getUniqueId()); }

    public void skip(Player p) {
        Run r = running.get(p.getUniqueId());
        if (r != null && cfg.getBoolean("skip-with-sneak", true)) r.skip = true;
    }

    public void stop(Player p) {
        Run r = running.get(p.getUniqueId());
        if (r != null) r.finish(false);
    }

    public void stopAll() {
        for (Run r : new ArrayList<>(running.values())) r.finish(false);
    }

    private static double num(Object o, double def) { return o instanceof Number n ? n.doubleValue() : def; }

    private List<Wp> waypoints() {
        List<Wp> out = new ArrayList<>();
        for (Map<?, ?> m : cfg.getMapList("waypoints")) {
            World w = Bukkit.getWorld(String.valueOf(m.get("world")));
            if (w == null) continue;
            Location l = new Location(w, num(m.get("x"), 0), num(m.get("y"), 100), num(m.get("z"), 0),
                    (float) num(m.get("yaw"), 0), (float) num(m.get("pitch"), 0));
            Object t = m.get("title"), s = m.get("subtitle");
            out.add(new Wp(l, (int) Math.max(1, num(m.get("ticks"), 100)),
                    t == null ? "" : String.valueOf(t), s == null ? "" : String.valueOf(s)));
        }
        return out;
    }

    public int count() { return cfg.getMapList("waypoints").size(); }

    public void addWaypoint(Player p, int ticks, String title, String sub) {
        List<Map<?, ?>> list = new ArrayList<>(cfg.getMapList("waypoints"));
        Location l = p.getLocation();
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("world", l.getWorld().getName());
        m.put("x", Math.round(l.getX() * 100) / 100.0);
        m.put("y", Math.round(l.getY() * 100) / 100.0);
        m.put("z", Math.round(l.getZ() * 100) / 100.0);
        m.put("yaw", Math.round(l.getYaw() * 10) / 10.0);
        m.put("pitch", Math.round(l.getPitch() * 10) / 10.0);
        m.put("ticks", ticks);
        m.put("title", title);
        m.put("subtitle", sub);
        list.add(m);
        cfg.set("waypoints", list);
        save();
    }

    public void clearWaypoints() {
        cfg.set("waypoints", new ArrayList<>());
        save();
    }

    private void save() {
        try { cfg.save(file); } catch (IOException e) { plugin.getLogger().warning("cinematic.yml kaydedilemedi: " + e.getMessage()); }
    }

    public void start(Player p) {
        if (!enabled() || running.containsKey(p.getUniqueId())) return;
        Run r = new Run(p, waypoints());
        running.put(p.getUniqueId(), r);
        r.runTaskTimer(plugin, 0L, 1L);
    }

    private final class Run extends BukkitRunnable {
        final Player p;
        final List<Wp> wps;
        final boolean camera;
        final Location orig;
        final GameMode gm;
        final boolean inv;
        final int introTotal;
        int intro;
        int seg = 0, t = 0;
        boolean skip, done;

        Run(Player p, List<Wp> wps) {
            this.p = p;
            this.wps = wps;
            this.camera = wps.size() >= 2;
            this.orig = p.getLocation().clone();
            this.gm = p.getGameMode();
            this.inv = p.isInvulnerable();
            this.introTotal = cfg.getInt("intro-ticks", 80);
            this.intro = introTotal;
            // cokme durumunda geri yuklemek icin kaydet
            plugin.data().set(p.getUniqueId(), "cinematic.gm", gm.name());
            if (camera) {
                p.setGameMode(GameMode.SPECTATOR);
                p.setInvulnerable(true);
            }
        }

        @Override
        public void run() {
            if (!p.isOnline()) { finish(false); return; }

            if (intro > 0) {
                if (intro == introTotal) {
                    p.sendTitle(Text.c(Text.fmt(cfg.getString("thanks.title", ""), "%player%", p.getName())),
                            Text.c(Text.fmt(cfg.getString("thanks.subtitle", ""), "%player%", p.getName())),
                            10, Math.max(introTotal - 20, 10), 10);
                    p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
                }
                if (camera) p.teleport(wps.get(0).loc());
                intro--;
                return;
            }

            if (!camera || skip) { finish(true); return; }

            Wp a = wps.get(seg), b = wps.get(seg + 1);
            if (t == 0 && !a.title().isEmpty()) {
                p.sendTitle(Text.c(a.title()), Text.c(a.sub()), 10, Math.max(Math.min(a.ticks() - 20, 80), 10), 10);
            }
            double f = (double) t / a.ticks();
            f = f * f * (3 - 2 * f); // yumusak gecis
            Location la = a.loc(), lb = b.loc();
            double dyaw = ((lb.getYaw() - la.getYaw() + 540) % 360) - 180;
            Location l = new Location(la.getWorld(),
                    la.getX() + (lb.getX() - la.getX()) * f,
                    la.getY() + (lb.getY() - la.getY()) * f,
                    la.getZ() + (lb.getZ() - la.getZ()) * f,
                    (float) (la.getYaw() + dyaw * f),
                    (float) (la.getPitch() + (lb.getPitch() - la.getPitch()) * f));
            p.teleport(l);
            t++;
            if (t >= a.ticks()) {
                seg++;
                t = 0;
                if (seg >= wps.size() - 1) finish(true);
            }
        }

        void finish(boolean completed) {
            if (done) return;
            done = true;
            try { cancel(); } catch (IllegalStateException ignored) {}
            running.remove(p.getUniqueId());
            p.setGameMode(gm);
            p.setInvulnerable(inv);
            p.resetTitle();
            if (camera) p.teleport(orig);
            if (p.isOnline()) plugin.data().set(p.getUniqueId(), "cinematic", null);
            if (completed && p.isOnline()) {
                p.sendTitle(Text.c(cfg.getString("outro.title", "")), Text.c(cfg.getString("outro.subtitle", "")), 10, 60, 20);
                p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
                Random rnd = new Random();
                for (int i = 0; i < 3; i++) {
                    Location fl = p.getLocation().add(rnd.nextInt(7) - 3, 0, rnd.nextInt(7) - 3);
                    Cosmetics.firework(fl);
                }
                for (String cmd : cfg.getStringList("outro.commands")) {
                    Bukkit.dispatchCommand(Bukkit.getConsoleSender(), Text.fmt(cmd, "%player%", p.getName()));
                }
            }
        }
    }
}

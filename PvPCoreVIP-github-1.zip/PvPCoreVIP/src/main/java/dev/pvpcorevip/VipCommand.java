package dev.pvpcorevip;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class VipCommand implements CommandExecutor, TabCompleter {
    private final VipPlugin plugin;

    public VipCommand(VipPlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (cmd.getName().equalsIgnoreCase("acikpartiler")) {
            if (s instanceof Player p) plugin.menus().openParties(p);
            return true;
        }

        if (a.length == 0) {
            if (!(s instanceof Player p)) return true;
            if (plugin.isVip(p)) plugin.menus().openMain(p); else plugin.send(p, "locked");
            return true;
        }

        String sub = a[0].toLowerCase();
        if (sub.equals("katil") && s instanceof Player p && a.length > 1) {
            Player host = Bukkit.getPlayerExact(a[1]);
            if (host == null) { plugin.send(p, "open-join-fail"); return true; }
            plugin.joinOpenParty(p, host.getUniqueId());
            return true;
        }

        // buradan sonrasi yonetici komutlari
        if (!s.hasPermission("pvpcorevip.admin")) { plugin.send(s, "no-perm"); return true; }

        switch (sub) {
            case "reload" -> {
                plugin.reloadConfig();
                plugin.cinematic().reload();
                plugin.send(s, "reloaded");
            }
            case "verdi" -> { // /vip verdi <oyuncu> -> tesekkur sinematigini test et
                if (a.length < 2) return true;
                Player t = Bukkit.getPlayerExact(a[1]);
                if (t != null) plugin.cinematic().start(t);
            }
            case "kamera" -> camera(s, a);
            default -> {}
        }
        return true;
    }

    private void camera(CommandSender s, String[] a) {
        if (a.length < 2) return;
        switch (a[1].toLowerCase()) {
            case "ekle" -> {
                if (!(s instanceof Player p) || a.length < 3) return;
                int ticks;
                try { ticks = Integer.parseInt(a[2]); } catch (NumberFormatException e) { return; }
                String rest = String.join(" ", Arrays.copyOfRange(a, 3, a.length));
                String[] parts = rest.split("\\|", 2);
                String title = parts[0].trim();
                String sub = parts.length > 1 ? parts[1].trim() : "";
                plugin.cinematic().addWaypoint(p, ticks, title, sub);
                plugin.send(p, "cam-added", "%count%", String.valueOf(plugin.cinematic().count()));
            }
            case "temizle" -> { plugin.cinematic().clearWaypoints(); plugin.send(s, "cam-cleared"); }
            case "test" -> {
                if (!(s instanceof Player p)) return;
                if (plugin.cinematic().count() < 2) plugin.send(p, "cam-none");
                plugin.cinematic().start(p);
            }
            default -> {}
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] a) {
        List<String> out = new ArrayList<>();
        if (!cmd.getName().equalsIgnoreCase("vip")) return out;
        if (a.length == 1) {
            out.add("katil");
            if (s.hasPermission("pvpcorevip.admin")) out.addAll(List.of("kamera", "verdi", "reload"));
        } else if (a.length == 2 && a[0].equalsIgnoreCase("kamera") && s.hasPermission("pvpcorevip.admin")) {
            out.addAll(List.of("ekle", "temizle", "test"));
        } else if (a.length == 2 && (a[0].equalsIgnoreCase("katil") || a[0].equalsIgnoreCase("verdi"))) {
            for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
        }
        String prefix = a.length == 0 ? "" : a[a.length - 1].toLowerCase();
        out.removeIf(x -> !x.toLowerCase().startsWith(prefix));
        return out;
    }
}

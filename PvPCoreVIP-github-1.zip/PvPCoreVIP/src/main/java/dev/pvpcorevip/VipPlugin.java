package dev.pvpcorevip;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class VipPlugin extends JavaPlugin {
    private VipData data;
    private Cinematic cinematic;
    private Cosmetics cosmetics;
    private VipMenus menus;
    private final Map<UUID, Long> lastAnnounce = new HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        data = new VipData(this);
        cinematic = new Cinematic(this);
        cosmetics = new Cosmetics(this);
        menus = new VipMenus(this);

        Bukkit.getPluginManager().registerEvents(new VipListener(this), this);
        Bukkit.getPluginManager().registerEvents(menus, this);

        VipCommand cmd = new VipCommand(this);
        getCommand("vip").setExecutor(cmd);
        getCommand("vip").setTabCompleter(cmd);
        getCommand("acikpartiler").setExecutor(cmd);

        if (Bukkit.getPluginManager().isPluginEnabled("LuckPerms")) {
            new LuckPermsHook(this);
            getLogger().info("LuckPerms bulundu: VIP verilince sinematik otomatik oynayacak.");
        } else {
            getLogger().warning("LuckPerms bulunamadi: sinematik sadece /vip verdi <oyuncu> ile tetiklenir.");
        }

        // lobi bakimi (zirh + VIP esyasi), 2 saniyede bir
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) cosmetics.tick(p);
        }, 60L, 40L);
        // veriyi periyodik kaydet
        Bukkit.getScheduler().runTaskTimerAsynchronously(this, () -> data.save(), 600L, 600L);
    }

    @Override
    public void onDisable() {
        cinematic.stopAll();
        data.save();
    }

    public VipData data() { return data; }
    public Cinematic cinematic() { return cinematic; }
    public Cosmetics cosmetics() { return cosmetics; }
    public VipMenus menus() { return menus; }

    public boolean isVip(Player p) {
        return p.hasPermission(getConfig().getString("vip-permission", "pvpcore.vip"));
    }

    // ---------- mesajlar ----------
    public String msg(String key, String... kv) {
        String raw = getConfig().getString("messages." + key, key);
        return Text.c(getConfig().getString("prefix", "") + Text.fmt(raw, kv));
    }

    public void send(CommandSender to, String key, String... kv) { to.sendMessage(msg(key, kv)); }

    // ---------- VIP verildi / alindi ----------
    public void vipGranted(Player p) {
        UUID id = p.getUniqueId();
        if (data.getBool(id, "thanked", false)) return;
        data.set(id, "thanked", true);
        if (p.getWorld().getName().equalsIgnoreCase(getConfig().getString("lobby-world", "spawn"))) {
            cinematic.start(p);
        } else {
            data.set(id, "pending", true); // lobiye donunce oynar
        }
    }

    public void vipRevoked(UUID id, Player p) {
        data.set(id, "thanked", false);
        data.set(id, "pending", null);
        data.setOpen(id, false);
        if (p != null) cosmetics.removeMarked(p, (byte) 0);
    }

    public void checkPending(Player p) {
        UUID id = p.getUniqueId();
        if (!data.getBool(id, "pending", false) || !isVip(p)) return;
        if (!p.getWorld().getName().equalsIgnoreCase(getConfig().getString("lobby-world", "spawn"))) return;
        data.set(id, "pending", null);
        cinematic.start(p);
    }

    // ---------- gunluk odul ----------
    public void daily(Player p) {
        UUID id = p.getUniqueId();
        long now = System.currentTimeMillis();
        long cd = getConfig().getLong("daily.cooldown-hours", 24) * 3_600_000L;
        long last = data.getLong(id, "daily", 0);
        if (now - last < cd) {
            long left = (cd - (now - last)) / 3_600_000L + 1;
            send(p, "daily-wait", "%time%", String.valueOf(left));
            return;
        }
        data.set(id, "daily", now);
        for (String c : getConfig().getStringList("daily.commands")) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), Text.fmt(c, "%player%", p.getName()));
        }
        send(p, "daily-ok");
    }


    /** Sohbete herkese acik parti duyurusu + tiklanabilir yesil KATIL butonu. */
    public void announceOpenParty(Player host) {
        long now = System.currentTimeMillis();
        long cd = getConfig().getLong("open-party.announce-cooldown-seconds", 30) * 1000L;
        Long last = lastAnnounce.get(host.getUniqueId());
        if (last != null && now - last < cd) return;
        lastAnnounce.put(host.getUniqueId(), now);

        LegacyComponentSerializer ser = LegacyComponentSerializer.legacySection();
        String text = Text.fmt(getConfig().getString("messages.open-announce", ""), "%player%", host.getName());
        Component button = ser.deserialize(Text.c(getConfig().getString("messages.open-button", "&a&l[KATIL]")))
                .clickEvent(ClickEvent.runCommand("/vip katil " + host.getName()))
                .hoverEvent(HoverEvent.showText(ser.deserialize(Text.c(getConfig().getString("messages.open-hover", "")))));
        Component line = ser.deserialize(Text.c(text)).append(Component.text(" ")).append(button);
        Bukkit.broadcast(line);
    }

    // ---------- acik parti ----------
    /** Lider /p davet atar, katilan /p kabul der. PvPCoreParty'nin kendi komutlari kullanilir. */
    public void joinOpenParty(Player joiner, UUID hostId) {
        Player host = Bukkit.getPlayer(hostId);
        if (host == null || !data.isOpen(hostId) || !isVip(host) || host.equals(joiner)) {
            send(joiner, "open-join-fail");
            return;
        }
        Bukkit.dispatchCommand(host, "p davet " + joiner.getName());
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (joiner.isOnline()) Bukkit.dispatchCommand(joiner, "p kabul " + host.getName());
        }, 5L);
        send(joiner, "open-join", "%player%", host.getName());
    }
}

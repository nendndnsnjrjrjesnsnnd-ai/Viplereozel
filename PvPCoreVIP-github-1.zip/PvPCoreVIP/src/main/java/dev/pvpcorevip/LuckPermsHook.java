package dev.pvpcorevip;

import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.event.node.NodeAddEvent;
import net.luckperms.api.event.node.NodeMutateEvent;
import net.luckperms.api.event.node.NodeRemoveEvent;
import net.luckperms.api.model.user.User;
import net.luckperms.api.node.Node;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.UUID;

/** LuckPerms'te vip grubu/yetkisi eklenince veya kaldirilinca tetiklenir (lp user X parent set vip). */
final class LuckPermsHook {
    private final VipPlugin plugin;

    LuckPermsHook(VipPlugin plugin) {
        this.plugin = plugin;
        LuckPerms lp = LuckPermsProvider.get();
        lp.getEventBus().subscribe(plugin, NodeAddEvent.class, e -> handle(e, true));
        lp.getEventBus().subscribe(plugin, NodeRemoveEvent.class, e -> handle(e, false));
    }

    private void handle(NodeMutateEvent e, boolean added) {
        if (!e.isUser()) return;
        Node n = (e instanceof NodeAddEvent a) ? a.getNode() : ((NodeRemoveEvent) e).getNode();
        String group = "group." + plugin.getConfig().getString("vip-group", "vip");
        String perm = plugin.getConfig().getString("vip-permission", "pvpcore.vip");
        if (!n.getKey().equalsIgnoreCase(group) && !n.getKey().equalsIgnoreCase(perm)) return;

        UUID id = ((User) e.getTarget()).getUniqueId();
        // izinlerin yeniden hesaplanmasi icin biraz bekle (parent set = once remove sonra add atar)
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            Player p = Bukkit.getPlayer(id);
            if (added) {
                if (p != null && plugin.isVip(p)) plugin.vipGranted(p);
            } else {
                if (p == null || !plugin.isVip(p)) plugin.vipRevoked(id, p);
            }
        }, 20L);
    }
}

package dev.pvpcorevip;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.*;

public final class VipMenus implements Listener {
    enum Type { MAIN, TRIM, EFFECTS, PARTIES }

    static final class Holder implements InventoryHolder {
        final Type type;
        Inventory inv;
        final Map<Integer, UUID> targets = new HashMap<>();
        Holder(Type t) { this.type = t; }
        @Override public Inventory getInventory() { return inv; }
    }

    private final VipPlugin plugin;

    public VipMenus(VipPlugin plugin) { this.plugin = plugin; }

    // ---------- yardimcilar ----------
    private Inventory make(Holder h, int size, String title) {
        Inventory inv = Bukkit.createInventory(h, size, Text.c(title));
        h.inv = inv;
        ItemStack f = it(Material.GRAY_STAINED_GLASS_PANE, " ", false);
        for (int i = 0; i < size; i++) inv.setItem(i, f);
        return inv;
    }

    private ItemStack it(Material m, String name, boolean glow, String... lore) {
        ItemStack i = new ItemStack(m);
        ItemMeta meta = i.getItemMeta();
        meta.setDisplayName(Text.c(name));
        List<String> l = new ArrayList<>();
        for (String s : lore) l.add(Text.c(s));
        meta.setLore(l);
        meta.addItemFlags(ItemFlag.values());
        if (glow) meta.setEnchantmentGlintOverride(true);
        i.setItemMeta(meta);
        return i;
    }

    private Material mat(String name, Material def) {
        Material m = Material.matchMaterial(name);
        return m == null ? def : m;
    }

    private String state(boolean on) { return on ? "&aAçık" : "&cKapalı"; }

    // ---------- ana menu ----------
    public void openMain(Player p) {
        UUID id = p.getUniqueId();
        VipData d = plugin.data();
        boolean arm = d.getBool(id, "armor", false);
        boolean open = d.isOpen(id);
        Inventory inv = make(new Holder(Type.MAIN), 45, "&5★ &dVIP Menü");
        inv.setItem(10, it(Material.NETHERITE_CHESTPLATE, "&8Netherite Zırh", arm,
                "&7Durum: " + state(arm), "", "&eTıkla: aç / kapat"));
        inv.setItem(12, it(mat("SENTRY_ARMOR_TRIM_SMITHING_TEMPLATE", Material.PAPER), "&bTrim Seçimi", false,
                "&7Zırhına özel desen ve renk seç.", "", "&eTıkla: menüyü aç"));
        inv.setItem(14, it(Material.LECTERN, "&dHerkese Açık Parti", open,
                "&7Durum: " + state(open), "&7Açıkken herkes davetsiz katılabilir.", "&8(Parti lideri sen olmalısın)", "", "&eTıkla: aç / kapat"));
        inv.setItem(16, it(Material.COMPASS, "&aAçık Partiler", false, "&7Katılabileceğin partileri gör.", "", "&eTıkla: listele"));
        inv.setItem(29, it(Material.FIREWORK_ROCKET, "&6Efektler", false, "&7Öldürme efekti ve vuruş partikülü.", "", "&eTıkla: menüyü aç"));
        inv.setItem(31, it(Material.CHEST, "&eGünlük Ödül", false, "&7Her gün bir kez alabilirsin.", "", "&eTıkla: ödülü al"));
        inv.setItem(33, it(Material.BARRIER, "&cKapat", false));
        p.openInventory(inv);
    }

    // ---------- trim menusu ----------
    public void openTrim(Player p) {
        UUID id = p.getUniqueId();
        String curP = plugin.data().getString(id, "trim.pattern", "");
        String curM = plugin.data().getString(id, "trim.material", "");
        Inventory inv = make(new Holder(Type.TRIM), 54, "&b✦ Trim Seçimi");
        inv.setItem(4, plugin.cosmetics().piece(id, Material.NETHERITE_CHESTPLATE, "&5Önizleme"));
        for (int i = 0; i < Cosmetics.PATTERNS.size(); i++) {
            String n = Cosmetics.PATTERNS.get(i);
            boolean sel = n.equals(curP);
            inv.setItem(9 + i, it(mat(n.toUpperCase() + "_ARMOR_TRIM_SMITHING_TEMPLATE", Material.PAPER),
                    "&f" + cap(n), sel, sel ? "&aSeçili" : "&eTıkla: desen seç"));
        }
        String[] icons = {"QUARTZ", "IRON_INGOT", "NETHERITE_INGOT", "REDSTONE", "COPPER_INGOT", "GOLD_INGOT",
                "EMERALD", "DIAMOND", "LAPIS_LAZULI", "AMETHYST_SHARD", "RESIN_CLUMP"};
        for (int i = 0; i < Cosmetics.TRIM_MATS.size(); i++) {
            String n = Cosmetics.TRIM_MATS.get(i);
            boolean sel = n.equals(curM);
            inv.setItem(27 + i, it(mat(icons[i], Material.PAPER), "&f" + cap(n), sel, sel ? "&aSeçili" : "&eTıkla: renk seç"));
        }
        inv.setItem(45, it(Material.ARROW, "&7Geri", false));
        inv.setItem(53, it(Material.RED_DYE, "&cTrim'i Kaldır", false));
        p.openInventory(inv);
    }

    // ---------- efekt menusu ----------
    public void openEffects(Player p) {
        UUID id = p.getUniqueId();
        String kill = plugin.data().getString(id, "fx.kill", "NONE");
        String hit = plugin.data().getString(id, "fx.hit", "NONE");
        Inventory inv = make(new Holder(Type.EFFECTS), 45, "&6✧ Efektler");
        String[] ki = {"BARRIER", "LIGHTNING_ROD", "FIREWORK_ROCKET", "PINK_DYE", "SOUL_TORCH", "BLAZE_POWDER"};
        for (int i = 0; i < Cosmetics.KILL_FX.size(); i++) {
            String n = Cosmetics.KILL_FX.get(i);
            boolean sel = n.equals(kill);
            inv.setItem(10 + i, it(mat(ki[i], Material.PAPER), "&fÖldürme: &e" + n, sel, sel ? "&aSeçili" : "&eTıkla: seç"));
        }
        List<String> parts = new ArrayList<>();
        parts.add("NONE");
        parts.addAll(plugin.getConfig().getStringList("hit-particles"));
        for (int i = 0; i < parts.size() && i < 9; i++) {
            String n = parts.get(i);
            boolean sel = n.equals(hit);
            inv.setItem(28 + i, it(n.equals("NONE") ? Material.BARRIER : Material.BLAZE_POWDER,
                    "&fVuruş: &e" + n, sel, sel ? "&aSeçili" : "&eTıkla: seç"));
        }
        inv.setItem(40, it(Material.ARROW, "&7Geri", false));
        p.openInventory(inv);
    }

    // ---------- acik partiler ----------
    public void openParties(Player p) {
        Holder h = new Holder(Type.PARTIES);
        Inventory inv = make(h, 54, "&a★ Açık Partiler");
        int slot = 0;
        for (UUID uid : plugin.data().openHosts()) {
            Player host = Bukkit.getPlayer(uid);
            if (host == null || !plugin.isVip(host) || slot >= 45) continue;
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta sm = (SkullMeta) head.getItemMeta();
            sm.setOwningPlayer(host);
            sm.setDisplayName(Text.c("&d" + host.getName() + " &7partisi"));
            sm.setLore(List.of(Text.c("&7Lider: &f" + host.getName()), "", Text.c("&eTıkla: katıl")));
            head.setItemMeta(sm);
            inv.setItem(slot, head);
            h.targets.put(slot, uid);
            slot++;
        }
        if (slot == 0) inv.setItem(22, it(Material.BARRIER, "&cŞu an açık parti yok", false));
        inv.setItem(49, it(Material.ARROW, "&7Kapat", false));
        p.openInventory(inv);
    }

    private String cap(String s) { return s.substring(0, 1).toUpperCase() + s.substring(1); }

    // ---------- tiklamalar ----------
    @EventHandler(priority = EventPriority.HIGH)
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof Holder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getInventory()) return;
        int s = e.getRawSlot();
        UUID id = p.getUniqueId();
        VipData d = plugin.data();

        // VIP degilse (yetki alinmis) menuyu kapat; acik partiler herkese aciktir
        if (h.type != Type.PARTIES && !plugin.isVip(p)) { p.closeInventory(); plugin.send(p, "locked"); return; }

        switch (h.type) {
            case MAIN -> {
                switch (s) {
                    case 10 -> {
                        boolean on = !d.getBool(id, "armor", false);
                        d.set(id, "armor", on);
                        if (on) plugin.cosmetics().applyArmor(p, true);
                        else plugin.cosmetics().removeMarked(p, Cosmetics.KIND_ARMOR);
                        plugin.send(p, on ? "armor-on" : "armor-off");
                        openMain(p);
                    }
                    case 12 -> openTrim(p);
                    case 14 -> {
                        boolean on = !d.isOpen(id);
                        d.setOpen(id, on);
                        plugin.send(p, on ? "open-on" : "open-off");
                        if (on) plugin.announceOpenParty(p);
                        openMain(p);
                    }
                    case 16 -> openParties(p);
                    case 29 -> openEffects(p);
                    case 31 -> { p.closeInventory(); plugin.daily(p); }
                    case 33 -> p.closeInventory();
                    default -> {}
                }
            }
            case TRIM -> {
                if (s >= 9 && s < 9 + Cosmetics.PATTERNS.size()) {
                    d.set(id, "trim.pattern", Cosmetics.PATTERNS.get(s - 9));
                    refreshTrim(p);
                } else if (s >= 27 && s < 27 + Cosmetics.TRIM_MATS.size()) {
                    d.set(id, "trim.material", Cosmetics.TRIM_MATS.get(s - 27));
                    refreshTrim(p);
                } else if (s == 45) openMain(p);
                else if (s == 53) {
                    d.set(id, "trim.pattern", null);
                    d.set(id, "trim.material", null);
                    plugin.send(p, "trim-cleared");
                    refreshTrim(p);
                }
            }
            case EFFECTS -> {
                if (s >= 10 && s < 10 + Cosmetics.KILL_FX.size()) {
                    d.set(id, "fx.kill", Cosmetics.KILL_FX.get(s - 10));
                    openEffects(p);
                } else if (s >= 28 && s < 37) {
                    List<String> parts = new ArrayList<>();
                    parts.add("NONE");
                    parts.addAll(plugin.getConfig().getStringList("hit-particles"));
                    int idx = s - 28;
                    if (idx < parts.size()) {
                        d.set(id, "fx.hit", parts.get(idx));
                        openEffects(p);
                    }
                } else if (s == 40) openMain(p);
            }
            case PARTIES -> {
                if (s == 49) { p.closeInventory(); return; }
                UUID host = h.targets.get(s);
                if (host != null) { p.closeInventory(); plugin.joinOpenParty(p, host); }
            }
        }
    }

    private void refreshTrim(Player p) {
        UUID id = p.getUniqueId();
        if (plugin.data().getBool(id, "armor", false)) plugin.cosmetics().applyArmor(p, true);
        String pat = plugin.data().getString(id, "trim.pattern", null);
        String mt = plugin.data().getString(id, "trim.material", null);
        if (pat != null && mt != null) plugin.send(p, "trim-set", "%pattern%", cap(pat), "%material%", cap(mt));
        openTrim(p);
    }
}
